<template>
    <header class="header border">
      헤더입니다.
    </header>
</template>

<script>
export default {
  name: 'default-header'
}
</script>

<style>
.border {
    border: 1px solid #000;
}
</style>
