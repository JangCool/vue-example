<template>
    <header class="header border">
     다른 헤더입니다.
    </header>
</template>

<script>
export default {
  name: 'other-header'
}
</script>

<style>
.border {
    border: 1px solid #000;
}
</style>
