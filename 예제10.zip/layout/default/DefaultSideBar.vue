<template>
    <div class="sidebar border">
        <p>사이드바 입니다.</p>
    </div>
</template>

<script>
export default {
  name: 'default-sidebar'
}
</script>

<style>
.border {
    border: 1px solid #000;
}
</style>
