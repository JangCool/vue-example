<template>
    <default-layout>
    </default-layout>
</template>

<script>
import DefaultLayout from '@/layout/DefaultLayout.vue'

export default {
  name: 'App',
  components: {
    'default-layout': DefaultLayout
  }
}
</script>

<style>
@import "~@/assets/main.css";
</style>
