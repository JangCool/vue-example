<template>
    <div class="border">
        <p>
            컨텐츠 입니다.
        </p>
    </div>
</template>

<script>
export default {
  name: 'default-content'
}
</script>

<style>
.border {
    border: 1px solid #000;
}
</style>
