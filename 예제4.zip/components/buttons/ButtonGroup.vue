<template>
    <div class="button-group">
        <button v-on:click="updateTitle">Emit 전달</button>
    </div>
</template>

<script>
export default {
  name: 'button-group',
  setup (props, { emit }) {
    const updateTitle = () => {
      console.log('click updateTitle...')
      //   emit('update-parent')
      emit('update-parent', { message: '데이터를 전송 합니다' })
    }
    return {
      updateTitle: updateTitle
    }
  }

}
</script>

<style>
.button-group{
    float: right;
}
</style>
