<template>
    <div class="card-header">
      <p>카드 헤더 입니당</p>
    </div>
</template>

<script>
export default {
  name: 'card-header'
}
</script>

<style>
.card-header {
  color: #fff!important;
  background-color: #2196F3!important;
  padding: 0.01em 16px;
  box-sizing: inherit;
  content: "";
  display: table;
  clear: both;
}
</style>
