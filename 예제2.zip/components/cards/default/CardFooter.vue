<template>
    <div class="card-footer">
      <p>카드 푸터 입니당</p>
    </div>
</template>

<script>
export default {
  name: 'card-footer'
}
</script>

<style>
.card-footer {
  color: #fff!important;
  background-color: #2196F3!important;
  padding: 0.01em 16px;
  box-sizing: inherit;
  content: "";
  display: table;
  clear: both;
}
</style>
