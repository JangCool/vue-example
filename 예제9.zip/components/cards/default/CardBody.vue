<template>
    <div class="card-body">
      <p>카드 바디 입니당</p>
    </div>
</template>

<script>
export default {
  name: 'card-body'
}
</script>

<style>
.card-body {
  color: #fff!important;
  background-color: #86a1b8!important;
  padding: 0.01em 16px;
  box-sizing: inherit;
  content: "";
  display: table;
  clear: both;
}
</style>
