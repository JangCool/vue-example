<template>
    <footer class="footer border">
        푸터입니다.
    </footer>
</template>

<script>
export default {
  name: 'default-footer'
}
</script>

<style>
.border {
    border: 1px solid #000;
}
</style>
